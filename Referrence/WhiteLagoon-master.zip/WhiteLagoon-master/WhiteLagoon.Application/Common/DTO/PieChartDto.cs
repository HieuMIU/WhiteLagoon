﻿namespace WhiteLagoon.Web.ViewModels
{
    public class PieChartDto
    {
        public decimal[] Series { get; set; }
        public string[] Labels { get; set; }
    }
}
